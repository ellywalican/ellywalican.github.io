(() => {
  const form = document.querySelector('#hire-form');
  const button = form.querySelector('button[type="submit"]');
  const status = document.querySelector('#form-status');
  const popup = document.querySelector('#hire-dialog');
  const trigger = document.querySelector('.hire-trigger');
  let activeTrigger = trigger;
  const close = () => popup.close();
  document.querySelectorAll('.hire-trigger, .hero-hire-trigger').forEach(opener => opener.addEventListener('click', () => {
    activeTrigger = opener;
    const menu = document.querySelector('.menu');
    if (menu.getAttribute('aria-expanded') === 'true') menu.click();
    popup.showModal();
    document.body.classList.add('hire-open');
    const initialFocus = matchMedia('(pointer: coarse)').matches
      ? popup.querySelector('.hire-close') : document.querySelector('#sender-name');
    initialFocus.focus({ preventScroll: true });
  }));
  popup.querySelector('.hire-close').addEventListener('click', close);
  popup.addEventListener('click', event => {
    const bounds = popup.getBoundingClientRect();
    if (event.target === popup && (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom)) close();
  });
  popup.addEventListener('close', () => {
    document.body.classList.remove('hire-open');
    const returnTarget = activeTrigger.getClientRects().length ? activeTrigger : document.querySelector('.menu');
    returnTarget.focus({ preventScroll: true });
  });
  let sending = false;
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (sending || !form.reportValidity()) return;
    if (form.elements.botcheck.checked) return;
    sending = true;
    button.disabled = true;
    button.textContent = 'Sending…';
    form.setAttribute('aria-busy', 'true');
    status.textContent = 'Submitting your message…';
    status.dataset.state = 'pending';
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);
    try {
      const data = Object.fromEntries(new FormData(form));
      data.name = data.name.trim();
      data.email = data.email.trim();
      data.message = data.message.trim();
      if (data.name.length < 2 || data.message.length < 10) throw new Error('Please enter at least 2 characters for your name and 10 characters for your message.');
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(data), signal: controller.signal
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || result?.success !== true) {
        throw new Error(response.status === 429
          ? 'Too many requests. Please wait a moment before trying again.'
          : 'Your message was not accepted. Please try again or use the email link below.');
      }
      status.dataset.state = 'success';
      status.textContent = 'Your message has been submitted. Thank you for reaching out!';
      form.reset();
    } catch (error) {
      status.dataset.state = 'error';
      status.textContent = error.name === 'AbortError'
        ? 'The request timed out, so submission could not be confirmed. Your message is still here; please check your connection before trying again.'
        : error instanceof TypeError
          ? 'Could not connect to the message service. Your message is still here. Please try again or use the email link below.'
          : error.message;
    } finally {
      clearTimeout(timeout);
      sending = false;
      button.disabled = false;
      button.innerHTML = 'Send Message <span aria-hidden="true">↗</span>';
      form.removeAttribute('aria-busy');
    }
  });
})();
