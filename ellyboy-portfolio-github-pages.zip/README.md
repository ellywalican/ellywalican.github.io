# Ellyboy Walican — Portfolio

Responsive personal portfolio. Static HTML, CSS, and JavaScript; no build step.

For GitHub Pages, select Settings → Pages → Deploy from a branch → main → / (root) → Save.

Contact form uses Web3Forms. The access key is a client-side form identifier, not an email account password. Project concept previews are labeled as such.
