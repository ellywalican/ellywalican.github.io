(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  const root = document.documentElement;

  // A short, dismissible first-visit introduction; never blocks page access.
  let showIntro = !reduceMotion.matches;
  try {
    showIntro = showIntro && !sessionStorage.getItem('elly-intro-seen');
    sessionStorage.setItem('elly-intro-seen', '1');
  } catch { /* The portfolio also works when browser storage is disabled. */ }
  if (showIntro) {
    const intro = document.createElement('div');
    intro.className = 'page-intro';
    intro.innerHTML = '<div class="intro-brand" aria-hidden="true">elly<span>.</span></div><p aria-hidden="true">A LITTLE CURIOSITY. A LOT OF POSSIBILITY.</p><div class="intro-track" aria-hidden="true"><i></i></div><button type="button" class="skip-intro">Skip intro ↗</button>';
    document.body.append(intro);
    const dismiss = () => {
      intro.classList.add('is-leaving');
      window.setTimeout(() => intro.remove(), 420);
    };
    intro.querySelector('button').addEventListener('click', dismiss, { once: true });
    const dismissOnKeyboard = event => {
      if (event.key === 'Tab' || event.key === 'Escape') {
        dismiss();
        document.removeEventListener('keydown', dismissOnKeyboard);
      }
    };
    document.addEventListener('keydown', dismissOnKeyboard);
    window.setTimeout(() => document.removeEventListener('keydown', dismissOnKeyboard), 1400);
    window.setTimeout(dismiss, 850);
    // CSS has its own fail-open timeout if a later script fails.
  }

  const reveals = document.querySelectorAll('.section-head, .about > div, .skills-grid article, .project, .journey-item, .contact-inner, footer');
  let revealObserver;
  const revealAll = () => {
    reveals.forEach(item => item.classList.remove('reveal-pending'));
    revealObserver?.disconnect();
  };
  if (!reduceMotion.matches && 'IntersectionObserver' in window) {
    revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.remove('reveal-pending');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });
    reveals.forEach((item, index) => {
      item.style.setProperty('--reveal-delay', `${Math.min(index % 3, 2) * 70}ms`);
      item.classList.add('reveal-pending');
      revealObserver.observe(item);
    });
  }
  // Anchor navigation and keyboard focus must always expose their content.
  document.addEventListener('focusin', event => {
    event.target.closest('.reveal-pending')?.classList.remove('reveal-pending');
  });
  reduceMotion.addEventListener('change', event => {
    if (event.matches) {
      revealAll();
      document.querySelector('.page-intro')?.remove();
    }
  });

  // Progress and active navigation update at most once per animation frame.
  const progress = document.createElement('div');
  progress.className = 'reading-progress';
  progress.setAttribute('aria-hidden', 'true');
  document.body.append(progress);
  const sectionLinks = [...document.querySelectorAll('nav a[href^="#"]')];
  const sections = sectionLinks.map(link => document.querySelector(link.getAttribute('href')));
  let framePending = false;
  const updateScroll = () => {
    const distance = root.scrollHeight - window.innerHeight;
    progress.style.transform = `scaleX(${distance > 0 ? Math.min(1, Math.max(0, window.scrollY / distance)) : 0})`;
    let activeIndex = -1;
    let activeTop = -Infinity;
    sections.forEach((section, index) => {
      const top = section?.getBoundingClientRect().top;
      if (top !== undefined && top <= window.innerHeight * 0.4 && top > activeTop) {
        activeIndex = index;
        activeTop = top;
      }
    });
    sectionLinks.forEach((link, index) => {
      if (index === activeIndex) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
    framePending = false;
  };
  const requestUpdate = () => {
    if (!framePending) { framePending = true; requestAnimationFrame(updateScroll); }
  };
  window.addEventListener('scroll', requestUpdate, { passive: true });
  window.addEventListener('resize', requestUpdate, { passive: true });
  updateScroll();

  // Animate the real filtered results rather than delaying the filter itself.
  document.querySelectorAll('[data-filter]').forEach(button => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.project:not([hidden])').forEach((card, index) => {
        card.classList.remove('reveal-pending');
        if (!reduceMotion.matches && typeof card.animate === 'function') {
          card.animate([
            { opacity: 0, transform: 'translateY(14px)' },
            { opacity: 1, transform: 'translateY(0)' }
          ], { duration: 320, delay: index * 45, easing: 'cubic-bezier(.2,.7,.3,1)', fill: 'backwards' });
        }
      });
      requestUpdate();
    });
  });

  // Keep pointer effects confined to the hero and desktop pointing devices.
  const heroArt = document.querySelector('.hero-art');
  let pointerFrame = 0;
  heroArt.addEventListener('pointermove', event => {
    if (reduceMotion.matches || !finePointer.matches || pointerFrame) return;
    pointerFrame = requestAnimationFrame(() => {
      const bounds = heroArt.getBoundingClientRect();
      const x = (event.clientX - bounds.left) / bounds.width;
      const y = (event.clientY - bounds.top) / bounds.height;
      heroArt.style.setProperty('--light-x', `${x * 100}%`);
      heroArt.style.setProperty('--light-y', `${y * 100}%`);
      heroArt.style.setProperty('--tilt-x', `${(0.5 - y) * 5}deg`);
      heroArt.style.setProperty('--tilt-y', `${(x - 0.5) * 5}deg`);
      pointerFrame = 0;
    });
  }, { passive: true });
  heroArt.addEventListener('pointerleave', () => {
    cancelAnimationFrame(pointerFrame);
    pointerFrame = 0;
    heroArt.style.setProperty('--tilt-x', '0deg');
    heroArt.style.setProperty('--tilt-y', '0deg');
  });
  window.addEventListener('pageshow', event => {
    if (event.persisted) { document.querySelector('.page-intro')?.remove(); revealAll(); requestUpdate(); }
  });
})();
