(() => {
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const pointer = matchMedia('(hover: hover) and (pointer: fine)');
  const canvas = document.createElement('canvas');
  canvas.className = 'pointer-particles';
  canvas.setAttribute('aria-hidden', 'true');
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  document.body.append(canvas);
  let particles = [];
  let frame = 0;
  let lastSpawn = 0;
  let previousTime = 0;
  let width = 0;
  let height = 0;
  const allowed = () => !motion.matches && pointer.matches && !document.hidden;
  const resize = () => {
    width = innerWidth;
    height = innerHeight;
    const ratio = Math.min(devicePixelRatio || 1, 1.5);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  };
  const clear = () => {
    cancelAnimationFrame(frame);
    frame = 0;
    particles = [];
    previousTime = 0;
    ctx.clearRect(0, 0, width, height);
    document.documentElement.classList.remove('glowing-cursor');
  };
  const draw = time => {
    if (!allowed()) { clear(); return; }
    const delta = previousTime ? Math.min(time - previousTime, 40) : 16;
    previousTime = time;
    ctx.clearRect(0, 0, width, height);
    particles = particles.filter(p => time - p.born < p.life);
    particles.forEach(p => {
      const age = (time - p.born) / p.life;
      p.x += p.vx * delta / 16;
      p.y += p.vy * delta / 16;
      p.vy += 0.012 * delta / 16;
      ctx.globalAlpha = (1 - age) * 0.75;
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (1 - age * 0.65), 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
    if (particles.length) frame = requestAnimationFrame(draw);
    else { frame = 0; previousTime = 0; }
  };
  window.addEventListener('pointermove', event => {
    if (!allowed() || event.pointerType !== 'mouse' || document.querySelector('.page-intro:not(.is-leaving)')) return;
    document.documentElement.classList.add('glowing-cursor');
    if (event.target.closest('input, textarea, select, [contenteditable="true"]')) {
      clear();
      return;
    }
    const time = performance.now();
    if (time - lastSpawn < 24) return;
    lastSpawn = time;
    if (!width) resize();
    for (let i = 0; i < 2; i++) {
      particles.push({ x: event.clientX + (Math.random() - 0.5) * 8,
        y: event.clientY + (Math.random() - 0.5) * 8,
        vx: (Math.random() - 0.5) * 1.8, vy: -Math.random() * 1.5,
        born: time, life: 450 + Math.random() * 300,
        size: 1.5 + Math.random() * 2.2,
        color: ['#74d7ff', '#729dff', '#b2b8ff'][Math.floor(Math.random() * 3)] });
    }
    if (particles.length > 80) particles.splice(0, particles.length - 80);
    if (!frame) frame = requestAnimationFrame(draw);
  }, { passive: true });
  window.addEventListener('resize', () => { if (width) { clear(); resize(); } }, { passive: true });
  window.addEventListener('blur', clear);
  window.addEventListener('pagehide', clear);
  document.addEventListener('visibilitychange', clear);
  document.documentElement.addEventListener('pointerleave', clear);
  motion.addEventListener('change', clear);
  pointer.addEventListener('change', clear);
})();
