const menu = document.querySelector('.menu');
const navigation = document.querySelector('nav');
menu.addEventListener('click', () => {
  const open = menu.getAttribute('aria-expanded') !== 'true';
  menu.setAttribute('aria-expanded', String(open));
  navigation.classList.toggle('open', open);
  menu.querySelector('span').textContent = open ? '−' : '＋';
});
navigation.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  navigation.classList.remove('open');
  menu.setAttribute('aria-expanded', 'false');
  menu.querySelector('span').textContent = '＋';
}));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && navigation.classList.contains('open')) {
    navigation.classList.remove('open');
    menu.setAttribute('aria-expanded', 'false');
    menu.querySelector('span').textContent = '＋';
    menu.focus();
  }
});
document.addEventListener('click', event => {
  if (!event.target.closest('header')) {
    navigation.classList.remove('open');
    menu.setAttribute('aria-expanded', 'false');
    menu.querySelector('span').textContent = '＋';
  }
});
document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('[data-filter]').forEach(item => {
    item.classList.toggle('active', item === button);
    item.setAttribute('aria-pressed', String(item === button));
  });
  document.querySelectorAll('.project').forEach(project => {
    project.hidden = button.dataset.filter !== 'all' && project.dataset.category !== button.dataset.filter;
  });
}));
const concepts = {
  "bitulok": [
    "Bitulok Express — Capstone 2",
    "Bitulok Express: Online Platform Food Ordering and Delivery System for Gabaldon, Nueva Ecija. The image shows the platform's administration console sign-in screen."
  ],
  "wallyboy": [
    "Wallyboy — Ordering system",
    "Customer registration, a product catalog, and order tracking in one ordering system."
  ],
  "bookwise": [
    "BookWise — Book borrowing system",
    "A library management system for borrowing and returning books."
  ],
  "amira": [
    "Amira Nova — Buy & delivery system",
    "A mobile application designed for buying and delivery services."
  ],
  "portfolio": [
    "Mini portfolio — Personal website",
    "A personal portfolio built with React and React Router to showcase projects and skills."
  ]
};
const dialog = document.querySelector('#project-dialog');
let projectTrigger;
document.querySelectorAll('[data-project]').forEach(button => button.addEventListener('click', () => {
  projectTrigger = button;
  const [title, description] = concepts[button.dataset.project];
  document.querySelector('#dialog-title').textContent = title;
  document.querySelector('#dialog-description').textContent = description;
  const preview = button.querySelector('.project-screenshot');
  const detailImage = document.querySelector('#project-detail-image');
  const imageLink = document.querySelector('#project-image-link');
  detailImage.src = preview.src;
  detailImage.alt = preview.alt;
  imageLink.href = preview.src;
  imageLink.setAttribute('aria-label', 'Open full-size image for ' + title);
  dialog.querySelector('.dialog-note').textContent = button.dataset.project === 'bitulok'
    ? 'Capstone 2 project. Preview uses the supplied Bitulok Express administration console screenshot. Source code and live demo links are not yet available.'
    : 'This image is an AI-generated UI concept illustrating a proposed design, not a screenshot of the implemented project. Source code and live demo links will be added when available.';
  dialog.showModal();
  document.body.classList.add('project-open');
}));

dialog.addEventListener('close', () => {
  document.body.classList.remove('project-open');
  projectTrigger?.focus({ preventScroll: true });
});
document.querySelectorAll('.close-dialog, .close-bottom').forEach(button => button.addEventListener('click', () => dialog.close()));
dialog.addEventListener('click', event => { if (event.target === dialog) { const bounds = dialog.getBoundingClientRect(); if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close(); } });
document.querySelector('#year').textContent = new Date().getFullYear();
